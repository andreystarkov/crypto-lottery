import BackgroundImage from './BackgroundImage'

export default BackgroundImage
