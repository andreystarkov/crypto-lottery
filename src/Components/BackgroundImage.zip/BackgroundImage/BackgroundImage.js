import React, { Component } from 'react'
import styled from 'styled-components'

import { Images } from 'Themes'

export const FadeInWrapper = styled.div`
  animation-delay: 0.2s;
  animation-duration: 1s;
  animation-timing-function: cubic-bezier(0.445, 0.05, 0.55, 0.95);
`

export const BackgroundIllustration = styled.div`
  background-image: url(${props => props.name ? Images.illustrations[props.name] : Images.illustrations.main});
  background-position: top ${props => props.offsetTop || '-20em'} center;
  background-attachment: fixed;
  background-repeat: no-repeat;
  background-size: cover;
  height: 100vh;
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  width: 100%;
`

export default class BackgroundImage extends Component {
  state = {
    scrollTop: null
  }

  componentDidMount () {
    window.addEventListener('scroll', this.handleScroll)
    this.handleScroll()
  }

  componentWillUnmount () {
    window.removeEventListener('scroll', this.handleScroll)
  }

  handleScroll = () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop
    if (scrollTop < 700) this.setState({ scrollTop })
  }

  render () {
    const { initialOpacity } = this.props
    const { scrollTop } = this.state
    const opacity = (initialOpacity || 1) - scrollTop / 1000
    return (
      <FadeInWrapper className='animated fadeIn'>
        <BackgroundIllustration
          {...this.props}
          style={{ opacity, transform: `scale(${1 + scrollTop * 0.000019})` }} />
      </FadeInWrapper>
    )
  }
}
